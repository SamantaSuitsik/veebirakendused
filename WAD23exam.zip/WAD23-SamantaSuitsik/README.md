# wad2023-exam1-22-12-2023

## Project setup
```
npm install
```

### Database info
```
Complete the information related to your database (db name, password) in the database.js file that is in the ../server directory
```

### Run the Back-end
```
npm run server
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Open Cypress 
```
npx cypress open
```