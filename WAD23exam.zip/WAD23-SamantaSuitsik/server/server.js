
const express = require('express');
const pool = require('./database');
const cors = require('cors')

const port = process.env.PORT || 3000;
const app = express();


app.use(cors({ origin: 'http://localhost:8080', credentials: true }));
app.use(express.json());

app.listen(port, () => {
    console.log("Server is listening to port " + port)
});


app.get('/api/courses', async(req, res) => {
    try {
        console.log("A GET all request has arrived");
        const course = await pool.query(
            "SELECT * FROM courses"
        );
        res.json(course.rows);
    } catch (err) {
        console.error(err.message);
    }
});

app.get('/api/Acourse/:id', async(req,res) => {
    try {
        const {id} = req.params;
        console.log("Get req for post")
        const aCourse = await pool.query(
            "SELECT * FROM courses WHERE id = $1", [id]
        );
        res.json(aCourse.rows);

    }
    catch (err) {
        console.error(err.message);
    }
})

app.put('/api/Acourse/:id'), async(req,res) => {
    try {
        const { id } = req.params;
        const course = req.body;
        console.log("An update request has arrived");
        const updatecourse = await pool.query(
            "UPDATE courses SET (id, studentsnumbers, groupsnumbers, description) = ($1, $2, $3,$4) WHERE id = $1 RETURNING*", [id, course.studentsnumbers, course.groupsnumbers, course.description]
        );
        res.json(updatecourse);
    }
    catch (e) {
        console.error(e)
    }
}