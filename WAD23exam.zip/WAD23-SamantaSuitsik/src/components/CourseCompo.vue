<template>
    <div class="container">
        <div class="row" v-for="course in courses" :key="id">
        <table>
            <th>Course name: </th>
            <th>Code:</th>
            <th>ECTS:</th>
            <th>Max No. of Students:</th>
            <th>No. of groups:</th>
            <tr>
                <td>{{ course.coursename }}</td>
                <td><a href="#" @click="navigateToACourse(course.id)">{{ course.coursecode }}</a></td>
                <td>{{ course.courseects }}</td>
                <td>{{ course.studentsnumbers }}</td>
                <td>{{ course.groupsnumbers }}</td>
            </tr>

        </table>
        </div>
    </div>
</template>

<script>
    
    export default {
        name: "CourseCompo",
        props: {
            courses: Array,
        },
        methods: {
            navigateToACourse(courseId) {

                console.log(courseId)
                this.$router.push(`/ACourse/${courseId}`);
            }
        }
    }

</script>

<style scoped>
    .container {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    .row {
        background-color: rgb(211, 204, 204);
        padding:10px;
        border-radius: 20px;

    }

    table {
        background-color: rgb(142, 107, 168);
    }

    td {
        padding: 20px;
    }
    th {
        padding-left: 15px;
        padding-right: 15px;
        padding-top: 10px;
    }

</style>