<template>
<div class="ACourse">
  <h1>{{ data.coursename }}</h1>
  <form>
    <label>MAX NUMBER OF STUDENTS:</label>
    <input name="maxnr" type="number" id="maxnr" v-model="data.studentsnumbers" required>
    <label>NUMBER OF GROUPS:</label>
    <input name="groupnr" type="number" id="groupnr" v-model="data.groupsnumbers" required>
    <label> COURSE DESCRIPTION:</label>
    <input name="desc" type="text" id="desc" v-model="data.description" required>
    
  </form>

    <button @click="Update(Acourse.id,Acourse)">Update Course</button>


</div>
</template>


<script>
export default {
  name: "ACourse",
  data() {
    return {
      data: [],
      Acourse: {
        id: "",
        studentsnumbers: "",
        groupsnumbers: "",
        description: ""
      }
    };
  },
  methods: {
    async getPost() {
      await fetch(`http://localhost:3000/api/Acourse/${this.$route.params.id}`)
        .then(res => res.json())
        .then(data => {
          console.log(data)
          this.data = data;
          
        })
        .catch(error => {
          console.log(error);
        })
    },

    Update(id, course) {
      fetch(`http://localhost:3000/api/Acourse/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify( {"id": id, "studentsnumbers": course.studentsnumbers, "groupsnumbers": course.groupsnumbers, "description": course.description}),
            })
        .then((response) => {
          this.$router.push("/");
        })
        .catch((e) => {
          console.log(e);
        });
    }

  },
  mounted() {
    this.getPost()
    console.log("mounted");
  } 
};
</script>

<style scoped>
  .ACourse {
    background-color: gray;

    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    border-radius: 20px;
  }
  form {
    display: flex;
    flex-direction: column;
    padding: 20px;
  
  }

  label {
    padding: 10px;
  }


</style>