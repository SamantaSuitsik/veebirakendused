/// <reference types = "cypress"/>  

it('Test 1', () => {
    cy.visit('http://localhost:8080/courses')
    cy.get('a').first().click();
    //cy.url().should("equals", "http://localhost:8080/ACourse/1")
    cy.visit('http://localhost:8080/ACourse/1')
    cy.get('label').length >= 3;
    cy.get('input').length >= 3;
    cy.get('#maxnr').clear().type("110");
    cy.get('button').should('be.visible');
    cy.get('button').click();
})